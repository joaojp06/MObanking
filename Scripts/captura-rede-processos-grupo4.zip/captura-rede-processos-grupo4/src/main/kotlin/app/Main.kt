package app

import com.github.britooo.looca.api.core.Looca
import entidade.*
import repositorio.*
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.locks.Lock
import kotlin.system.exitProcess

open class Main {
    companion object {
        @JvmStatic
        fun main(args: Array<String>) {
            while (true) {
                try {
                    executarPrograma()
                } catch (e: Exception) {
                    println("Ocorreu um erro: ${e.message}. Reiniciando...")
                }
            }
        }
    }
}


fun executarPrograma() {
    var looca = Looca()
    var registro = Registro()


    // SEÇÃO 1)

    // ------- CONFIGURAÇÃO -------

    // Bloco abaixo chama todos os arquivos que precisamos

    var usuario = Usuario()
    var empresa = Empresa()
    var servidor = Servidor()
    var limiteServicoMonitorado = LimiteServicoMonitorado()

    // amrmazenendo todas as funções dos repositorios em variaveis
    var usuarioRepositorio = UsuarioRepositorio()
    var empresaRepositorio = EmpresaRepositorio()
    var servidorRepositorio = ServidorRepositorio()
    var registroRepositorio = RegistroRepositorio()
    var limiteServicoMonitoradoRepositorio = LimiteServicoMonitoradoRepositorio()

    // Todo arquivo repositorio precisa de configuração, ou seja, se conectar com banco de dados
    registroRepositorio.configurar()
    usuarioRepositorio.configurar()
    empresaRepositorio.configurar()
    servidorRepositorio.configurar()
    limiteServicoMonitoradoRepositorio.configurar()


    // Ao capturar, retornarmos uma data com hora, essa função formata isso
    fun formatarData(data: String): String {
        val formatterEntrada = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
        val formatterSaida = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")
        val dataFormatada = LocalDateTime.parse(data, formatterEntrada)
        return dataFormatada.format(formatterSaida)
    }

    fun formatarEnderecoMac (enderecoMac: String): String {
        return enderecoMac.replace(":", "-")
    }

    // FIM  SEÇÃO 1) FIM


    // ------- PROGRAMA -------


    // SEÇÃO 2)


    //Print de boas vindas
    println(
        """
       
        Sistema de captura de rede - Mobanking
       
    """.trimIndent()
    )


    // ao pedir email e senha, usamos as funções de set, porque as variaveis estão em private set
    print("Digite seu email: ")
    usuario.setEmail(readln())
    print("Digite sua senha: ")
    usuario.setSenha(readln())


    // Armazenamos o retorno da função existe usuario na variavel "usuarioRes"

    var usuarioRes = usuarioRepositorio.existeUsuario(usuario)


    // FIM SEÇÃO 2) FIM


    // SEÇÃO 3)


    //Verifica se o retorno é true, ou seja, existe algum usuario com o email e senha inseridos ?
    if (usuarioRes) {

        //Se sim, eu chamos a função autenticar, e como eu sei que o usuario existe
        // já armazeno a fkEmpresa

        var idEmpresa = usuarioRepositorio.autenticarUsuarioEmpresa(usuario).fkEmpresa


        //Com id da empresa, chamo a função verPlano, de ver a fkPlano dessa empresa


        // SEÇÃO 3.1)


        if (empresaRepositorio.verPlano(idEmpresa).fkPlano == 3) {


            println()
            println("Captura de dados de rede e processos autorizada com sucesso!")
            println()

            print("Deseja iniciar a captura agora [1] Sim [2] Não: ")
            var respostaCaptura = readln().toInt()

            if (respostaCaptura == 1) {


                println("Iniciando captura....")

                // Função insert do Mac do servidor
                var mac: String = looca.rede.grupoDeInterfaces.interfaces[0].enderecoMac

                mac = formatarEnderecoMac(mac)

                servidor.setEnderecoMac(mac)
                println("Endereço MAC da máquina $mac")

                // Procura qual é a fkServidor vinculada ao endereço MAC
                if (servidorRepositorio.existeServidor(servidor)) {
                    println("Máquina identificada com sucesso! 😀 ")
                    var fkServidor = servidorRepositorio.verServidor(servidor).id


                    while (true) {
                        println()

                        // ----- SCRIPT DE CAPTURA E INSERÇÃO: REDE -----
                        var valorPrimario: Long = looca.rede.grupoDeInterfaces.interfaces[0].bytesEnviados

                        registro.setValor(valorPrimario)
                        registro.fkServico = 4
                        registro.fkServidor = fkServidor
                        registro.fkAlertaPrevisao =
                            null // Limpando esse campo pois não se aplica para o serviço de rede

                        // Função insert com os valores de registro

//                        registroRepositorio.inserir(registro)
                        if (registroRepositorio.inserirRede(registro)) {
                            //Listar os ultimos inserts do servidor com fkServico = 4
                            // fkServico = 4 se refere a captura de rede
                            var lista = registroRepositorio.listarRede(registro)
                            var bytes = lista.valor
                            var megabytes = bytes / 1048576
                            println(
                                """
                        ------------DADOS DE REDE------------
                        Valor -> $megabytes Mb
                        Data e hora: ${formatarData(lista.data)}
                    """.trimIndent()
                            )
                        } else {
                            println(
                                """
                                Erro ao capturar dados de rede

                            """.trimIndent()
                            )
                        }

                        // ----- FIM SCRIPT DE CAPTURA E INSERÇÃO FIM -----


                        // ----- SCRIPT DE CAPTURA E INSERÇÃO: NÚMERO DE PROCESSOS -----
                        // Obtém o tamanho da lista de processos em execução
                        var qtdProcessos = looca.grupoDeProcessos.processos.size.toLong();

                        // Coloca na classe a fkServico referente ao serviço de processos
                        registro.fkServico = 5

                        // Coloca a fkServidor na classe
                        registro.fkServidor = fkServidor

                        // Insere a quantidade de processos em execução na classe

                        registro.setQtdProcessos(qtdProcessos)

                        // Pega o limite de processos do servidor para atingir 100% de RAM
                        limiteServicoMonitorado.fkServidor = fkServidor
                        var limiteProcessos =
                            limiteServicoMonitoradoRepositorio.verLimiteProcessos(limiteServicoMonitorado).valor

                        // Pega o limite de porcentagem de uso da RAM estabelecido pelo usuário para gerar alerta
                        limiteServicoMonitorado.fkServidor = fkServidor
                        var limiteRam = limiteServicoMonitoradoRepositorio.verLimiteRam(limiteServicoMonitorado).valor

                        // Guarda na variável a quantidade de processos que representa o atingimento do limite do uso de RAM estabelecido pelo usuário
                        limiteProcessos = (limiteProcessos * limiteRam) / 100

                        fun faltaPraAtingir(): Double {
                            val diferenca = limiteProcessos - qtdProcessos
                            val aumentoPercentual = (diferenca.toDouble() / qtdProcessos) * 100

                            return aumentoPercentual
                        }

                        val aumentoPercentual = faltaPraAtingir()

                        if (aumentoPercentual in 50.0..100.0) {
                            registro.fkAlertaPrevisao = 1
                        } else if (aumentoPercentual in 20.0..49.9) {
                            registro.fkAlertaPrevisao = 2
                        } else if (aumentoPercentual < 20) {
                            registro.fkAlertaPrevisao = 3
                        }

                        // ----- FIM SCRIPT DE CAPTURA E INSERÇÃO FIM -----

                        // Função insert com os valores da classe registro


                        if (registroRepositorio.inserirProcessos(registro)) {
                            var lista = registroRepositorio.listarProcessos(registro)
                            var valor = lista.valor
                            println(
                                """
                             ------------PROCESSOS------------
                             Dado coletado com sucesso
                             $qtdProcessos processos estão em execução!
                             Data e hora: ${formatarData(lista.data)}
                        """.trimIndent()
                            )
                        } else {
                            println(
                                """
                                ------------PROCESSOS------------
                                Erro ao capturar dado
                            """.trimIndent()
                            )
                        }

                        Thread.sleep(5000)

                    }
                } else {
                    // Cenário onde a máquina não está registrada no banco

                    println("Máquina não encontrada no sistema, tente novamente!")
                    executarPrograma()
                }

                // FIM SEÇÃO 3.1) FIM


                // SEÇÃO 3.2)


                // a cada 5 segundos o while será executado


                // FIM SEÇÃO 3.2) FIM

            } else {
                //Cenário onde o usuário digitou 2, ou ,seja não quer monitorar no momento
                println()
                println("Quando desejar capturar, realize o login novamente")
                println("saindo do sistema...")
                Thread.sleep(5000)

                //executa tudo de novo, para voltar para o login
                executarPrograma()
            }

        } else {

            //cenário onde a empresa não tem o plano PRO e permite apenas a captura de dados de processo

            println(
                """
                    Sua empresa não tem o plano PRO, apenas a captura de procecssos foi autorizada :)
                """.trimIndent()
            )
            Thread.sleep(3000)

            println()

            print("Deseja iniciar a captura agora [1] Sim [2] Não: ")
            var respostaCaptura = readln().toInt()

            if (respostaCaptura == 1) {


                println("Iniciando captura....")

                // Função insert do Mac do servidor
                var mac: String = looca.rede.grupoDeInterfaces.interfaces[0].enderecoMac

                mac = formatarEnderecoMac(mac)

                println("Endereço MAC da Máquina: $mac")

                servidor.setEnderecoMac(mac)
                // Insere um novo servidor no banco somente se o endereço MAC não estiver cadastrado ainda
                if (servidorRepositorio.existeServidor(servidor)) {
                    println("Máquina identificada com sucesso! 😀 ")
                    // Guarda a fk do servidor com o MAC
                    var fkServidor = servidorRepositorio.verServidor(servidor).id

                    while (true) {
                        println()

                        // ----- SCRIPT DE CAPTURA E INSERÇÃO: NÚMERO DE PROCESSOS -----
                        // Obtém o tamanho da lista de processos em execução
                        var qtdProcessos = looca.grupoDeProcessos.processos.size.toLong();

                        // Coloca na classe a fkServico referente ao serviço de processos
                        registro.fkServico = 5

                        // Coloca a fkServidor na classe
                        registro.fkServidor = fkServidor

                        // Insere a quantidade de processos em execução na classe

                        registro.setQtdProcessos(qtdProcessos)

                        // Pega o limite de processos do servidor para atingir 100% de RAM
                        limiteServicoMonitorado.fkServidor = fkServidor
                        var limiteProcessos =
                            limiteServicoMonitoradoRepositorio.verLimiteProcessos(limiteServicoMonitorado).valor

                        // Pega o limite de porcentagem de uso da RAM estabelecido pelo usuário para gerar alerta
                        limiteServicoMonitorado.fkServidor = fkServidor
                        var limiteRam = limiteServicoMonitoradoRepositorio.verLimiteRam(limiteServicoMonitorado).valor

                        // Guarda na variável a quantidade de processos que representa o atingimento do limite do uso de RAM estabelecido pelo usuário
                        limiteProcessos = (limiteProcessos * limiteRam) / 100

                        fun faltaPraAtingir(): Double {
                            val diferenca = limiteProcessos - qtdProcessos
                            val aumentoPercentual = (diferenca.toDouble() / qtdProcessos) * 100

                            return aumentoPercentual
                        }

                        val aumentoPercentual = faltaPraAtingir()

                        if (aumentoPercentual in 50.0..100.0) {
                            registro.fkAlertaPrevisao = 1
                        } else if (aumentoPercentual in 20.0..49.9) {
                            registro.fkAlertaPrevisao = 2
                        } else if (aumentoPercentual < 20) {
                            registro.fkAlertaPrevisao = 3
                        }

                        // ----- FIM SCRIPT DE CAPTURA E INSERÇÃO FIM -----

                        // Função insert com os valores da classe registro


                        if (registroRepositorio.inserirProcessos(registro)) {
                            var lista = registroRepositorio.listarProcessos(registro)
                            var valor = lista.valor
                            println(
                                """
                             ------------PROCESSOS------------
                             Dado coletado com sucesso
                             $qtdProcessos processos estão em execução!
                             Data e hora: ${formatarData(lista.data)}
                        """.trimIndent()
                            )
                        } else {
                            println(
                                """
                                ------------PROCESSOS------------
                                Erro ao capturar dado
                            """.trimIndent()
                            )
                        }

                        Thread.sleep(5000)

                    }
                } else {
                    // Cenário onde a máquina não está registrada no banco

                    println("Máquina não encontrada no sistema, tente novamente!")
                    executarPrograma()

                }

                // FIM SEÇÃO 3.1) FIM


                // SEÇÃO 3.2)


                // a cada 5 segundos o while será executado


                // FIM SEÇÃO 3.2) FIM

            } else {
                //Cenário onde o usuário digitou 2, ou ,seja não quer monitorar no momento
                println()
                println("Quando desejar capturar, realize o login novamente")
                println("saindo do sistema...")
                Thread.sleep(5000)

                //executa tudo de novo, para voltar para o login
                executarPrograma()
            }


            // FIM SEÇÃO 3) FIM


        }


    } else {
        //Cenário onde o email e senha não foram encontrados no banco
        println(
            """
                
            Email e/ou senha incorreto(s)
            
            Realize o login novamente
            
            
        """.trimIndent()
        )
        Thread.sleep(3000)

        //executa tudo novamente
        executarPrograma()

    }
}