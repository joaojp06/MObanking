package entidade

class Empresa {

    var id:Int = 0
    var fkPlano: Int = 0
    var razaoSocial: String = ""
    var cnpj: Int = 0
        private set
    var status: String = ""
        private set

    fun setCnpj(novoValor: Int){
        if (novoValor == 14){
            cnpj = novoValor
        }
    }

    fun setStatus(novoValor: String){
        if(novoValor.length > 4){
            status = novoValor
        }
    }

}