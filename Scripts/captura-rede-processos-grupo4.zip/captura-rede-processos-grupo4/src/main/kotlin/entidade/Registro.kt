package entidade

class Registro {
    var id: Int = 0
    var fkServidor: Int = 0
    var fkServico: Int = 0
    var fkAlertaPrevisao: Int? = null
    var valor: Long = 0
        private set
    var data: String = ""


    fun setValor(novoValor: Long): String {
        if (novoValor > 0) {
            valor = novoValor
        } else {
            return "O servidor não está enviando bytes"
        }
        return "Tudo OK com bytes enviados"
    }

    fun setQtdProcessos(novoValor: Long) {
        if (novoValor > 0) {
            valor = novoValor
        }
    }

}