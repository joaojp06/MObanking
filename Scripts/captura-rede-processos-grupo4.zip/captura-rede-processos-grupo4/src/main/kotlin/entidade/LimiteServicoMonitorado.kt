package entidade

class LimiteServicoMonitorado {

    var id: Int = 0
    var fkServidor : Int = 0
    var fkServico : Int = 0
    var valor : Double = 0.0
    var unidadeMedida : String = ""

}