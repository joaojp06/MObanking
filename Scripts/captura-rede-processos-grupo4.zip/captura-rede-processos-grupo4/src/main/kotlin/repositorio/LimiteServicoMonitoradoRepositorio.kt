package repositorio

import entidade.LimiteServicoMonitorado
import org.apache.commons.dbcp2.BasicDataSource
import org.springframework.jdbc.core.BeanPropertyRowMapper
import org.springframework.jdbc.core.JdbcTemplate

class LimiteServicoMonitoradoRepositorio {

    lateinit var jdbcTemplate: JdbcTemplate

    fun configurar() {
        val dataSource = BasicDataSource()
        dataSource.driverClassName = "com.mysql.cj.jdbc.Driver"
        dataSource.url =
            "jdbc:mysql://localhost:3306/mobanking" // substitua 'seu_banco_de_dados' pelo nome do seu banco de dados
        dataSource.username = "root"
        dataSource.password = "05012006jp"

        jdbcTemplate = JdbcTemplate(dataSource)
    }

    fun verLimiteProcessos(limiteServicoMonitorado: LimiteServicoMonitorado) : LimiteServicoMonitorado {
        val limiteProcessos = jdbcTemplate.queryForObject(
            "select * from limite_servico_monitorado where fkServidor = ? and fkServico = 5;",
            BeanPropertyRowMapper(LimiteServicoMonitorado::class.java),
            limiteServicoMonitorado.fkServidor
        )
        return limiteProcessos
    }

    fun verLimiteRam (limiteServicoMonitorado: LimiteServicoMonitorado) : LimiteServicoMonitorado {
        val limiteRam = jdbcTemplate.queryForObject(
            "select * from limite_servico_monitorado where fkServidor = ? and fkServico = 2 order by id desc limit 1;",
            BeanPropertyRowMapper(LimiteServicoMonitorado::class.java),
            limiteServicoMonitorado.fkServidor
        )
        return limiteRam
    }

}