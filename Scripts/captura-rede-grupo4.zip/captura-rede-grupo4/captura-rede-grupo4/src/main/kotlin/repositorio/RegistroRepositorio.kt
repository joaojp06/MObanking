package repositorio

import entidade.Registro
import entidade.Usuario
import org.apache.commons.dbcp2.BasicDataSource
import org.springframework.jdbc.core.BeanPropertyRowMapper
import org.springframework.jdbc.core.JdbcTemplate

class RegistroRepositorio {


    lateinit var jdbcTemplate: JdbcTemplate

    fun configurar() {
        val dataSource = BasicDataSource()
        dataSource.driverClassName = "com.mysql.cj.jdbc.Driver"
        dataSource.url = "jdbc:mysql://localhost:3306/mobanking" // substitua 'seu_banco_de_dados' pelo nome do seu banco de dados
        dataSource.username = "root"
        dataSource.password = "sptech"

        jdbcTemplate = JdbcTemplate(dataSource)
    }

    fun inserir(novoValor: Registro): Boolean{
        var qtdLinhas = jdbcTemplate.update("""
            insert into registro (fkServidor, fkServico, valor) values (?,?,?)
        """.trimIndent(),
            novoValor.fkServidor,
            novoValor.fkServico,
            novoValor.valor)

        return qtdLinhas > 0
    }

    fun listar(valor: Registro): Registro {
        var listaRegistro = jdbcTemplate.queryForObject(
            "select * from registro where fkServidor = ? and fkServico = 4 order by data desc limit 1;",
            BeanPropertyRowMapper(Registro::class.java),
            valor.fkServidor,
        )
        return listaRegistro
    }




}