package entidade

class Usuario {

    var id: Int = 0
    var fkEmpresa: Int = 0
    var fkTipoUsuario: Int = 0
    var nome: String = ""
        private set
    var cpf: String = ""
        private set
    var email: String = ""
        private set
    var senha: String = ""
        private set
    var status: String = ""
        private set

    fun setNome(novoValor: String){
        if(novoValor.length > 2){
            nome = novoValor
        }
    }
    fun setCpf(novoValor: String){
        if(novoValor.length == 11){
            cpf = novoValor
        }
    }
    fun setSenha(novoValor: String){
        if(novoValor.length > 2){
            senha = novoValor
        }
    }
    fun setEmail(novoValor: String){
        if(novoValor.length > 2){
            email = novoValor
        }
    }
    fun setStatus(novoValor: String){

        if(novoValor.length > 2){
            status = novoValor
        }

    }
}
