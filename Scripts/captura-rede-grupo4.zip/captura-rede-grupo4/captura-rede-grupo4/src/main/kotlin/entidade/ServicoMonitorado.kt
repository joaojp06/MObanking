package entidade

class ServicoMonitorado {

    var id: Int = 0
    var fkServidor = 0
    var fkServico = 0
    var capacidadeTotal: Double = 0.0
        private set
    var unidadeMedida: String = ""
        private set

    fun setCapacidadeTotal(novoValor: Double){
        if(novoValor > -1){
            capacidadeTotal = novoValor
        }
    }

    fun setUnidadeMedida(novoValor: String){
        if(novoValor.length > 3){
            unidadeMedida = novoValor
        }
    }

}