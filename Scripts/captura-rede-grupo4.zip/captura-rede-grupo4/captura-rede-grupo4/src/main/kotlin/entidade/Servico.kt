package entidade

class Servico {

    var id: Int = 0
    var nome: String = ""
        private set
    var descricao: String = ""
        private set
    var unidadeMedida: String = ""
        private set

    fun setNome(novoValor: String){
        if(novoValor.length > 3){
            nome = novoValor
        }
    }

    fun setDescricao(novoValor: String){
        if(novoValor.length > 3){
            descricao = novoValor
        }
    }

    fun setUnidadeMedida(novoValor: String){
        if(novoValor.length > 3){
            unidadeMedida = novoValor
        }
    }

}