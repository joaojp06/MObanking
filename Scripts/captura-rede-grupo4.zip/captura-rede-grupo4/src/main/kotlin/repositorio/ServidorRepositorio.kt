package repositorio

import entidade.Empresa
import entidade.Registro
import entidade.Servidor
import entidade.Usuario
import org.apache.commons.dbcp2.BasicDataSource
import org.springframework.jdbc.core.BeanPropertyRowMapper
import org.springframework.jdbc.core.JdbcTemplate
import org.springframework.jdbc.core.queryForObject

class ServidorRepositorio {
    lateinit var jdbcTemplate: JdbcTemplate

    fun configurar() {
        val dataSource = BasicDataSource()
        dataSource.driverClassName = "com.mysql.cj.jdbc.Driver"
        dataSource.url = "jdbc:mysql://localhost:3306/mobanking" // substitua 'seu_banco_de_dados' pelo nome do seu banco de dados
        dataSource.username = "root"
        dataSource.password = "urubu100"

        jdbcTemplate = JdbcTemplate(dataSource)
    }

    fun existeServidor(valor: Servidor): Boolean {
        val qtdExistentes = jdbcTemplate.queryForObject(
            "select count(*) from servidor where enderecoMac = ?",
            Int::class.java,
            valor.macServidor
        )
        return qtdExistentes > 0
    }

    fun inserir(novoValor: Servidor): Boolean{
        var qtdLinhas = jdbcTemplate.update("""
            insert into servidor (fkEmpresa, status, enderecoMac) values (3, 'ativo', ?)
        """.trimIndent(),
            novoValor.macServidor)

        return qtdLinhas > 0
    }

}