package repositorio

import com.github.javafaker.Bool
import entidade.Empresa
import entidade.Usuario
import jdk.incubator.foreign.CLinker.VaList
import org.apache.commons.dbcp2.BasicDataSource
import org.springframework.jdbc.core.BeanPropertyRowMapper
import org.springframework.jdbc.core.JdbcTemplate

class UsuarioRepositorio {

    lateinit var jdbcTemplate: JdbcTemplate

    fun configurar() {
        val dataSource = BasicDataSource()
        dataSource.driverClassName = "com.mysql.cj.jdbc.Driver"
        dataSource.url = "jdbc:mysql://localhost:3306/mobanking"
        dataSource.username = "root"
        dataSource.password = "urubu100"

        jdbcTemplate = JdbcTemplate(dataSource)
    }

    fun existeUsuario(valor: Usuario): Boolean {
        val qtdExistentes = jdbcTemplate.queryForObject(
            "select count(*) from usuario where email = ? and senha = ?",
            Int::class.java,
            valor.email,
            valor.senha
        )
        return qtdExistentes > 0
    }

    fun autenticarUsuarioEmpresa(valor: Usuario): Usuario {
        var empresa = jdbcTemplate.queryForObject(
            "select * from usuario where email = ? and senha = ? ",
            BeanPropertyRowMapper(Usuario::class.java),
            valor.email,
            valor.senha
        )
        return empresa
    }

}