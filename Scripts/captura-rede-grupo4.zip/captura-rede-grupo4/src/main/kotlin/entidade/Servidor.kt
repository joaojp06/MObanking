package entidade

class Servidor {

    var id: Int = 0
    var fkEmpresa: Int = 0
        private set
    var funcao: String = ""
        private set
    var macServidor = ""
        private set

    fun setFkEmpresa(novoValor: Int){
        if(novoValor > 0){
            fkEmpresa = novoValor
        }
    }

    fun setFuncao(novoValor: String){
        if(novoValor != ""){
            funcao = novoValor
        }
    }

    fun setMacServidor(novoValor: String) {
        if (novoValor.length == 17) {
            macServidor = novoValor
        }
    }

}