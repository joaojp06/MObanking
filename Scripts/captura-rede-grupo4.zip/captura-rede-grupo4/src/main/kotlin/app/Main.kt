package app

import com.github.britooo.looca.api.core.Looca
import entidade.Empresa
import entidade.Registro
import entidade.Servidor
import entidade.Usuario
import repositorio.EmpresaRepositorio
import repositorio.RegistroRepositorio
import repositorio.ServidorRepositorio
import repositorio.UsuarioRepositorio
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.locks.Lock
import kotlin.system.exitProcess

open class Main {
    companion object {
        @JvmStatic
        fun main(args: Array<String>) {
            while (true) {
                try {
                    executarPrograma()
                } catch (e: Exception) {
                    println("Ocorreu um erro: ${e.message}. Reiniciando...")
                }
            }
        }
    }
}


fun executarPrograma() {
    var looca = Looca()
    var registro = Registro()





    // SEÇÃO 1)

    // ------- CONFIGURAÇÃO -------

    // Bloco abaixo chama todos os arquivos que precisamos

    var usuario = Usuario()
    var empresa = Empresa()
    var servidor = Servidor()

    // amrmazenendo todas as funções dos repositorios em variaveis
    var usuarioRepositorio = UsuarioRepositorio()
    var empresaRepositorio = EmpresaRepositorio()
    var servidorRepositorio = ServidorRepositorio()
    var registroRepositorio = RegistroRepositorio()

    // Todo arquivo repositorio precisa de configuração, ou seja, se conectar com banco de dados
    registroRepositorio.configurar()
    usuarioRepositorio.configurar()
    empresaRepositorio.configurar()
    servidorRepositorio.configurar()


    // Ao capturar, retornarmos uma data com hora, essa função formata isso
    fun formatarData(data: String): String {
        val formatterEntrada = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
        val formatterSaida = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")
        val dataFormatada = LocalDateTime.parse(data, formatterEntrada)
        return dataFormatada.format(formatterSaida)
    }

    // FIM  SEÇÃO 1) FIM


    // ------- PROGRAMA -------


    // SEÇÃO 2)


    //Print de boas vindas
    println(
        """
       
        Sistema de captura de rede - Mobanking
       
    """.trimIndent()
    )


    // ao pedir email e senha, usamos as funsções de set, porque as variaveis estão em private set
    print("Digite seu email: ")
    usuario.setEmail(readln())
    print("Digite sua senha: ")
    usuario.setSenha(readln())


    // Armazenamos o retorno da função existe usuario na variavel "usuarioRes"

    var usuarioRes = usuarioRepositorio.existeUsuario(usuario)


    // FIM SEÇÃO 2) FIM


    // SEÇÃO 3)


    //Verifica se o retorno é true, ou seja, existe algum usuario com o email e senha inseridos ?
    if (usuarioRes) {

        //Se sim, eu chamos a função autenticar, e como eu sei que o usuario existe
        // já armazeno a fkEmpresa

        var idEmpresa = usuarioRepositorio.autenticarUsuarioEmpresa(usuario).fkEmpresa


        //Com id da empresa, chamo a função verPlano, de ver a fkPlano dessa empresa


        // SEÇÃO 3.1)


        if (empresaRepositorio.verPlano(idEmpresa).fkPlano == 3) {




            println()
            println("Captura de dados de rede autorizada com sucesso!")
            println()

            print("Deseja iniciar a captura agora [1] Sim [2] Não: ")
            var respostaCaptura = readln().toInt()

            if (respostaCaptura == 1) {


                println("Iniciando captura....")

                // Função insert do Mac do servidor
                var mac: String = looca.rede.grupoDeInterfaces.interfaces[0].enderecoMac
                println(mac)
                servidor.setMacServidor(mac)
                // Insere um novo servidor no banco somente se o endereço MAC não estiver cadastrado ainda
                if (!servidorRepositorio.existeServidor(servidor)) {
                    servidorRepositorio.inserir(servidor)
                }

                // FIM SEÇÃO 3.1) FIM


                // SEÇÃO 3.2)


                // a cada 5 segundos o while será executado
                while (true) {
                    println()

                    // ----- SCRIPT DE CAPTURA E INSERÇÃO -----
                    var valorPrimario: Long = looca.rede.grupoDeInterfaces.interfaces[0].bytesEnviados

                    registro.setValor(valorPrimario)
                    registro.fkServico = 4
                    registro.fkServidor = 9
                    // ----- FIM SCRIPT DE CAPTURA E INSERÇÃO FIM -----

                    // Função insert com os valores de registro
                    registroRepositorio.inserir(registro)


                    //Listar os ultimos inserts do servidor 9 com fkServico = 4
                    // fkServico = 4 se refere a captura de rede
                    var lista = registroRepositorio.listar(registro)
                    var bytes = lista.valor
                    var megabytes = bytes / 1048576
                    println("""
                        Valor -> $megabytes Mb"
                        "Data e hora: ${formatarData(lista.data)}"
                    """.trimIndent())

                    Thread.sleep(5000)

                }

                // FIM SEÇÃO 3.2) FIM

            } else {
                //Cenário onde o usuário digitou 2, ou ,seja não quer monitorar no momento
                println()
                println("Quando desejar capturar, realize o login novamente")
                println("saindo do sistema...")
                Thread.sleep(5000)

                //executa tudo de novo, para voltar para o login
                executarPrograma()
            }

        } else {

            //cenário onde a empresa não tem o plano PRO e não permite a captura de dados

            println(
                """
                    
                    Sua empresa não tem o plano PRO, entre em contato para assinar :)
                """.trimIndent()
            )
            Thread.sleep(3000)
        }


        // FIM SEÇÃO 3) FIM


    } else {
        //Cenário onde o email e senha não foram encontrados no banco
        println(
            """
                
            Email e/ou senha incorreto(s)
            
            Realize o login novamente
            
            
        """.trimIndent()
        )
        Thread.sleep(3000)

        //executa tudo novamente
        executarPrograma()

    }


}